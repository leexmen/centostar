This directory contains bash libraries used by scripts.

Configuration files for kickstart (Fedora) and preseed (Ubuntu) are in
osbash/netboot.

The osbash-ssh-keys can be automatically installed into osbash
VMs to make them accessible.

The templates used to build Windows batch files are in the wbatch subdirectory.
