This directory contains the insecure ssh keys used by osbash for logging into
the node VMs.
