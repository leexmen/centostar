The files in this directory are used to create Windows batch scripts that
can build base disks and VM clusters.
