The log files in this directory are written (and removed) by osbash/wbatch and
the scripts running within the VMs.

The status subdirectory is used by the VM scripts to inform osbash/wbatch
about their progress.
