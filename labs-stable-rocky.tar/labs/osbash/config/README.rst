The configuration files in this directory are used by osbash/wbatch and
by scripts running inside the VMs (scripts directory).
