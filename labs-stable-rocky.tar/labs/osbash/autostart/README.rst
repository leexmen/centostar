osbash/wbatch copy shell scripts (*.sh) into this directory to have them
automatically executed (and removed) upon boot.
