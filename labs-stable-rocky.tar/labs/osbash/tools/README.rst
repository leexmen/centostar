The tools in this directory are for advanced users and developers. They
can be used to test changes in the training-cluster.
