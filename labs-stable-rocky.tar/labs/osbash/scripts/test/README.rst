The scripts in this directory can be used to test the training-cluster.
