All scripts in this directory run within the VMs.

They install and configure OpenStack components and any other required
software (such as databases).

Before these generic scripts run, scripts from the osbash subdirectory
set up the VM and configure basic networking.
