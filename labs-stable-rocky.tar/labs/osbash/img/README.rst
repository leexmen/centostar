OsBash
------

About
-----

By default, osbash will put into this directory its base disk images
(base-*-<distro>.vdi), the VM export images (labs-<distro>.ova),
and all installation ISO images it may download.

    - 'img' folder stores all the base disk and ISO images.
    - To find individual virtualbox disk images, please look into the
      virtualbox default machine folder.
      - For Linux: "~/VirtualBox/labs/"
      - In case your default folder is at another location (manually set)
        please get the location by opening the VirtualBox GUI at this location
        "File>Preferences>General>Default Machine Folder"

